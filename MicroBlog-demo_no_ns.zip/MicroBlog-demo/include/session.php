<?php
/**
 * Created by JetBrains PhpStorm.
 * User: samir
 * Date: 10.11.11
 * Time: 15:24
 * To change this template use File | Settings | File Templates.
 */
 session_start();
?>
