<?php
/**
 * Created by JetBrains PhpStorm.
 * User: samir
 * Date: 13.11.11
 * Time: 18:40
 * To change this template use File | Settings | File Templates.
 */
class ConfigDB {
    //constants
    const DbAddress = 'localhost';
    const DbUsername = 'root';
    const DbPassword = '';
    const DbDatabase = 'microblog';
    const DbPort = 3306;
}
?>