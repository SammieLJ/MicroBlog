<?php
/**
 * Created by JetBrains PhpStorm.
 * User: samir
 * Date: 13.11.11
 * Time: 17:00
 * To change this template use File | Settings | File Templates.
 */

include_once("classes/Microblog/Config/ConfigDB.php");

class WriteToDB {

    //member vars
    private $db;
    private $query;

    //returned insert id
    private $insertId;

    //update ok
    private $updateOk;

    function __construct() {
        $this->db = new mysqli(ConfigDB::DbAddress,
                                ConfigDB::DbUsername,
                                ConfigDB::DbPassword,
                                ConfigDB::DbDatabase,
                                ConfigDB::DbPort);

        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
        //$this->query = $query;
    }

    function writeNewPassword($password, $userId) {

        /* escape chars */
        $password = mysql_real_escape_string($password);

        $this->query = "UPDATE users SET `password`=? WHERE id=?";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("si", $password, $userId);

            /* execute query */
            $this->updateOk = $stmt->execute();
        }

        /* close connection */
        $stmt->close();

        return $this->updateOk;
    }

    function addEntry($headline, $comment, $email, $website, $userId) {

         /* escape chars */
        $headline = mysql_real_escape_string($headline);
        $comment = mysql_real_escape_string($comment);
        $email = mysql_real_escape_string($email);
        $website = mysql_real_escape_string($website);
        //$userId is setted by db

        $this->query = "INSERT INTO `entries`(`headline`,`body`,`email`,`weburl`,`idUser`,`datestamp`) VALUES (?, ?, ?, ?, ?, now())";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("ssssi",$headline, $comment, $email, $website, $userId);

            /* execute query */
            $stmt->execute();

            /* return new id */
            $this->insertId = $stmt->insert_id;
        }

        /* close connection */
        $stmt->close();

        return $this->insertId;
    }

    function updateEntry($entryId, $headline, $comment, $email, $website) {

         /* escape chars */
        $headline = mysql_real_escape_string($headline);
        $comment = mysql_real_escape_string($comment);
        $email = mysql_real_escape_string($email);
        $website = mysql_real_escape_string($website);
        //entryId is setted by db

        $this->query = "UPDATE `entries`
                        SET `headline`=?, `body`=?, `email`=?, `weburl`=?
                        WHERE `idEntry`=?";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("ssssi",$headline, $comment, $email, $website, $entryId);

            /* execute query */
            $stmt->execute();

        }

        /* close connection */
        $stmt->close();
    }

    function deleteEntry($entryId) {
        /* escape chars */
        $entryId = mysql_real_escape_string($entryId);

        $this->query = "UPDATE `entries` SET `deleted`=TRUE WHERE `idEntry`=?";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("i", $entryId);

            /* execute query */
            $this->updateOk = $stmt->execute();
        }

        /* close connection */
        $stmt->close();

        return $this->updateOk;
    }

    function addNewUser($userName, $password, $userLevelId) {

        /* escape chars */
        $userName = mysql_real_escape_string($userName);
        $password = mysql_real_escape_string($password);
        $userLevelId = mysql_real_escape_string($userLevelId);

        $this->query = "INSERT INTO users (`username`, `password`, `userLevelId`)
                        VALUES (?, ?, ?)";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("ssi", $userName, $password, $userLevelId);

            /* execute query */
            $stmt->execute();

            /* return new id */
            $this->insertId = $stmt->insert_id;
        }

        /* close connection */
        $stmt->close();

        return $this->insertId;
    }

    function deleteUser($userId) {
        /* escape chars */
        $userId = mysql_real_escape_string($userId);

        $this->query = "UPDATE users SET deleted=TRUE WHERE `id`=?";
        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("i", $userId);

            /* execute query */
            $this->updateOk = $stmt->execute();
        }

        /* close connection */
        $stmt->close();

        return $this->updateOk;
    }
}
?>