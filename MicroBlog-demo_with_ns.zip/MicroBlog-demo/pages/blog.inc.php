<?php
if(!isset($_SESSION)) {
     session_start();
}
if (!isset($_SESSION['username'])) {
    //forward to index.php
    print "<script>";
    print " self.location='../index.php';"; // Comment this line if you don't want to redirect
    print "</script>";
    die("You must be logged in! <a href='../index.php'>Click here</a> for login! ");
}

//include("classes/Microblog/Model/Entry.php");
include_once("classes/Microblog/Db/ReadFromDB.php");

$entries = array();
$readFromDB = new \classes\Microblog\Db\ReadFromDB();
$entries = $readFromDB->getEntries();
unset($readFromDB);  //unload object

 /* check if we have some entries */
if (empty($entries)) {
?>
    <div id="entry"><h3>Ni nobene objave!</h3></div>
<?php
} else {
/* print all microblog entries */
foreach ($entries as $value) {
?>
    <div id="entry">
    <div>
        <?php
        if ($_SESSION['userlevel'] === 1 && $_SESSION['userid'] === $value->getUserId()) {
        ?>
            <a href="member.php?entryId=<?=$value->getEntryId()?>">Popravi</a>
        <?php
        }

        if ($_SESSION['userlevel'] === 0) {
        ?>
            <a href="member.php?entryId=<?=$value->getEntryId()?>">Popravi</a>&nbsp;<a href="deleteEntry.php?entryId=<?=$value->getEntryId()?>">Briši</a>
        <?php
        }
        ?>
    </div>
    <h3>#<?=$value->getEntryId()?>&nbsp;<?=$value->getHeadline()?></h3>
    <div><?=$value->getBody()?></div><br />
    <div>Avtor: <?=$value->getAuthor()?></div>
    <div>Kontakt: <i><a href="mailto:<?=$value->getEmail()?>"><?=$value->getEmail()?></a></i></div>
    <?php
    $temp_weburl = $value->getWeburl();
    if (!empty($temp_weburl)) {
    ?>
    <div>Vir: <a href="<?=$temp_weburl?>"><?=$temp_weburl?></a></div>
<?php
    }
?>
   </div>
<?php
    } //end of foreach
}//end of if-else
?>
<script type="text/javascript" src="scripts/jquery.js"></script>
<script>
    //static header and menu height
    var headerAndMenuHeight = 125;

    //when page loads - samirs
    $(document).ready(function(){
        var docHeight = $(window).height();
        var divHeight = docHeight - headerAndMenuHeight;

        $('#content').height(divHeight);
    });

    //when page resizes - samirs
    $(window).resize(function() {
        var docHeight = $(window).height();
        var divHeight = docHeight - headerAndMenuHeight;
        $('#content').height(divHeight);
    });
</script>