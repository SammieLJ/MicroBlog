<?php
/**
 * Created by JetBrains PhpStorm.
 * User: samir
 * Date: 13.11.11
 * Time: 9:44
 * To change this template use File | Settings | File Templates.
 */

 $warrningDivStart = "<html><body><link href=\"stylesheets/member.css\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\" /><div id='content'><div id='entry'><h3>Sporočilo!</h3>";
 $warrningDivEnd = "</div></div></body></html>";
?>