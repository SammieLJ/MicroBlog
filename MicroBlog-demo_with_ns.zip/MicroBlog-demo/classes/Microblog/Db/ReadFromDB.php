<?php
/**
 * Created by JetBrains PhpStorm.
 * User: samir
 * Date: 13.11.11
 * Time: 18:29
 * To change this template use File | Settings | File Templates.
 */
namespace classes\Microblog\Db;
include_once("classes/Microblog/Model/Entry.php");
include_once("classes/Microblog/Model/User.php");
include_once("classes/Microblog/Config/ConfigDB.php");

class ReadFromDB {

    //member vars
    private $db;
    private $query;

    //for Entry reading
    private $idEntry;
    private $headline;
    private $body;
    private $email;
    private $weburl;
    private $id_User;
    private $date;
    private $author;

    //for password reading
    private $password;

    //for user login
    //private $users_id;
    private $users_name;
    private $users_password;
    private $user_level;
    private $role_desc;

    //for user roles
    private $idRole;
    private $ShortDescription;
    private $LongDescription;

    //getEntry
    private $entryObj;

    function __construct() {
        $this->db = new \mysqli(\classes\Microblog\Config\ConfigDB::DbAddress,
                                \classes\Microblog\Config\ConfigDB::DbUsername,
                                \classes\Microblog\Config\ConfigDB::DbPassword,
                                \classes\Microblog\Config\ConfigDB::DbDatabase,
                                \classes\Microblog\Config\ConfigDB::DbPort);

        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
    }

    function getUserPassword($userId) {
        $this->query = "SELECT `password` FROM users WHERE id=? AND deleted=FALSE";

        if ($stmt = $this->db->prepare($this->query)) {

            /* bind sql stmnt params */
            $stmt -> bind_param("i", $userId);

            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->password);

            while ($stmt->fetch()) {
                $userPassword = $this->password;
            }

        }

        /* close statement */
        $stmt->close();
        
        return $userPassword;
    }

    function getEntries() {
        $temp_entries = array();
        $this->query = "SELECT en.`idEntry`, en.`headline`, en.`body`, en.`email`, en.`weburl`, en.`idUser`, en.`datestamp`, u.`username`
                  FROM entries AS en
                  INNER JOIN users AS u
                  ON en.`idUser`=u.`id`
                  WHERE en.`deleted`=0";


        if ($stmt = $this->db->prepare($this->query)) {
            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->idEntry, $this->headline, $this->body, $this->email, $this->weburl, $this->id_User, $this->date, $this->author);

            /* fetch values */
            while ($stmt->fetch()) {
                $entryObj = new \classes\Microblog\Model\Entry($this->idEntry, $this->headline, $this->body, $this->email, $this->weburl, $this->id_User, $this->date, $this->author);
                $temp_entries[] = $entryObj;
            }
        }
        /* close connection */
        $stmt->close();

        return $temp_entries;
    }

    function getEntry($entryId) {
        $this->query = "SELECT en.`idEntry`, en.`headline`, en.`body`, en.`email`, en.`weburl`, en.`idUser`, en.`datestamp`, u.`username`
                  FROM entries AS en
                  INNER JOIN users AS u
                  ON en.`idUser`=u.`id`
                  WHERE en.`deleted`=0 AND en.`idEntry`=?";


        if ($stmt = $this->db->prepare($this->query)) {
             /* escape chars */
            $entryId = mysql_real_escape_string($entryId);

            /* bind sql stmnt params */
            $stmt -> bind_param("i",$entryId);

            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->idEntry, $this->headline, $this->body, $this->email, $this->weburl, $this->id_User, $this->date, $this->author);

            /* fetch values */
            while ($stmt->fetch()) {
                $this->entryObj = new \classes\Microblog\Model\Entry($this->idEntry, $this->headline, $this->body, $this->email, $this->weburl, $this->id_User, $this->date, $this->author);
            }
        }
        /* close connection */
        $stmt->close();

        return $this->entryObj;
    }

    function getLoginUser($username, $password, &$dbUserId, &$dbusername, &$dbpassword, &$dbUserLevel, &$dbRoleDesc) {
        $numrows = 0;
        $this->query = "SELECT u.`id`, u.`username`, u.`password`, u.`userLevelId`, r.`ShortDesc`
                  FROM users u
                  INNER JOIN roles r
                  ON u.`userLevelId` = r.`idRole`
                  WHERE u.`username`=? AND u.`password`=? AND deleted=FALSE";

        if ($stmt = $this->db->prepare($this->query)) {
            /* escape chars */
            $username = mysql_real_escape_string($username);
            $password = mysql_real_escape_string($password);

            /* bind sql stmnt params */
            $stmt -> bind_param("ss",$username, $password);

            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->id_User, $this->users_name, $this->users_password, $this->user_level, $this->role_desc);

            /* fetch values */
            while ($stmt->fetch()) {
                $dbUserId = $this->id_User;
                $dbusername = $this->users_name;
                $dbpassword = $this->users_password;
                $dbUserLevel = $this->user_level;
                $dbRoleDesc = $this->role_desc;
                $numrows += 1;
            }
        }

        /* close connection */
        $stmt->close();

        return $numrows;
    }

    function getUsersList() {
        $usersList = array();
        $this->query = "SELECT u.`id`, u.`username`, u.`password`, u.`userLevelId`, r.`ShortDesc`
                        FROM users u
                        INNER JOIN roles r
                        ON u.`userLevelId` = r.`idRole` AND deleted=FALSE";
       if ($stmt = $this->db->prepare($this->query)) {
            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->id_User, $this->users_name, $this->users_password, $this->user_level, $this->role_desc);

            /* fetch values */
            while ($stmt->fetch()) {
                $userObj = new \classes\Microblog\Model\User($this->id_User,
                           $this->users_name,
                           $this->users_password,
                           $this->user_level,
                           $this->role_desc);
                $usersList[] = $userObj;
            }
        }
        /* close connection */
        $stmt->close();

        return $usersList;
    }

    function getUserRolesList() {
        $userRolesList = array();

        $this->query = "SELECT `idRole`, `ShortDesc`, `Description` FROM roles";
        if ($stmt = $this->db->prepare($this->query)) {
            /* execute query */
            $stmt->execute();

            /* bind result variables */
            $stmt->bind_result($this->idRole, $this->ShortDescription, $this->LongDescription);

            /* fetch values */
            while ($stmt->fetch()) {
                $userRolesList[$this->idRole] = $this->LongDescription;
            }
        }
        /* close connection */
        $stmt->close();

        return $userRolesList;
    }

}
?>
